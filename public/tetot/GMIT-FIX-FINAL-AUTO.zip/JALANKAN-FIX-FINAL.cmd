@echo off
cd /d D:\CODING\gereja\kharismanew
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0SELESAIKAN-GMIT-VERCEL.ps1"
echo.
echo =============================================
echo PROSES SELESAI. JANGAN TUTUP JIKA ADA ERROR.
echo =============================================
pause
